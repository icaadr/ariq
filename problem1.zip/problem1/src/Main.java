import java.util.Scanner;
public class Main {
    public static void main(String[] args){
        Scanner input=new Scanner (System.in);
        int alas, tinggi;
        double luas;

        System.out.println("Masukkan Nilai Alas:");
        alas=input.nextInt();
        System.out.println("Masukkan Nilai Tinggi:");
        tinggi=input.nextInt();
        luas=(0.5*alas*tinggi);
        System.out.println("Luas Segitiga adalah = " + luas);




    }
}